class Ultra {
    public:
        Ultra();
        int read(int idx);
        void debug();
};